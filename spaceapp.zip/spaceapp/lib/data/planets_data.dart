import '../models/planet.dart';

const List<Planet> planets = [
  Planet(
    name: 'Earth',
    image: 'assets/images/earth.png',
    detailsImage: 'assets/images/earth_details.png',
    description:
    "Earth is the only known planet in the universe that supports life. "
        "Its unique combination of factors, including liquid water, "
        "a breathable atmosphere, and a suitable distance from the Sun, "
        "has created the ideal conditions for the development of complex organisms.",
    distance: '149598026 km',
    day: '23.93 hours',
    year: '1 Earth year',
    radius: '6371 km',
    mass: '5.972 × 10²⁴ kg',
    gravity: '9.81 m/s²',
    surfaceArea: '5.10 × 10⁸ km²',
  ),
  Planet(
    name: 'Mercury',
    image: 'assets/images/mercury.png',
    detailsImage: 'assets/images/mercury.png',
    description:
    'Mercury is the smallest planet in our solar system and the closest '
        'planet to the Sun. It has a rocky surface covered with craters.',
    distance: '57900000 km',
    day: '1407.6 hours',
    year: '88 Earth days',
    radius: '2439 km',
    mass: '3.301 × 10²³ kg',
    gravity: '3.7 m/s²',
    surfaceArea: '7.48 × 10⁷ km²',
  ),
];