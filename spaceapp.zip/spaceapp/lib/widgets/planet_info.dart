
import 'package:flutter/material.dart';
import '../models/planet.dart';

class PlanetInfo extends StatelessWidget {
  final Planet planet;

  const PlanetInfo({
    super.key,
    required this.planet,
  });

  Widget infoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white70,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              value,
              textAlign: TextAlign.end,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'About',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          planet.description,
          style: const TextStyle(
            color: Colors.white70,
            fontSize: 12,
            height: 1.6,
          ),
        ),
        const SizedBox(height: 22),
        infoRow('Distance from Sun (km)', planet.distance),
        infoRow('Length of Day (hours)', planet.day),
        infoRow('Orbital Period', planet.year),
        infoRow('Radius (km)', planet.radius),
        infoRow('Mass (kg)', planet.mass),
        infoRow('Gravity (m/s²)', planet.gravity),
        infoRow('Surface Area (km²)', planet.surfaceArea),
      ],
    );
  }
}
