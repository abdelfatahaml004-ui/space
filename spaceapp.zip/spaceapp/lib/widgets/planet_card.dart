
import 'package:flutter/material.dart';
import '../models/planet.dart';

class PlanetCard extends StatelessWidget {
  final Planet planet;

  const PlanetCard({
    super.key,
    required this.planet,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Center(
        child: Image.asset(
          planet.image,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) {
            return const Icon(
              Icons.public,
              color: Colors.white,
              size: 130,
            );
          },
        ),
      ),
    );
  }
}
