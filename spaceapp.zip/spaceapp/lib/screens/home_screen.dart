
import 'package:flutter/material.dart';
import '../data/planets_data.dart';
import '../models/planet.dart';
import '../widgets/planet_card.dart';
import '../widgets/arrow_button.dart';
import 'details_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int selectedIndex = 0;

  Planet get selectedPlanet => planets[selectedIndex];

  void nextPlanet() {
    setState(() {
      selectedIndex = (selectedIndex + 1) % planets.length;
    });
  }

  void previousPlanet() {
    setState(() {
      selectedIndex =
          (selectedIndex - 1 + planets.length) % planets.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Stack(
          children: [
            // Background
            Positioned.fill(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const ColoredBox(
                    color: Color(0xFF0D0D0D),
                  ),

                  Positioned(
                    top: -100,
                    left: 0,
                    right: 0,
                    height: screenHeight * 0.55,
                    child: Image.asset(
                      'assets/images/space.png',
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    ),
                  ),

                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    height: screenHeight * 0.48,
                    child: const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Color(0x990D0D0D),
                            Color(0xFF0D0D0D),
                          ],
                          stops: [0.2, 0.7, 1.0],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Page Content
            SingleChildScrollView(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: screenHeight,
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 28),

                    const Text(
                      'Explore',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    SizedBox(height: screenHeight * 0.10),

                    const Padding(
                      padding: EdgeInsets.symmetric(horizontal: 22),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text(
                          'Which planet\nwould you like to explore?',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 21,
                            fontWeight: FontWeight.bold,
                            height: 1.6,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 15),

                    SizedBox(
                      height: screenHeight * 0.39,
                      width: double.infinity,
                      child: PlanetCard(
                        key: ValueKey(selectedPlanet.name),
                        planet: selectedPlanet,
                      ),
                    ),

                    // Space before arrows
                    const SizedBox(height: 40),

                    // Arrows and planet name
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          ArrowButton(
                            icon: Icons.arrow_back,
                            onPressed: previousPlanet,
                          ),

                          Text(
                            selectedPlanet.name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 21,
                              fontWeight: FontWeight.bold,
                            ),
                          ),

                          ArrowButton(
                            icon: Icons.arrow_forward,
                            onPressed: nextPlanet,
                          ),
                        ],
                      ),
                    ),

                    // Space before Explore button
                    const SizedBox(height: 55),

                    // Explore Button
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 22),
                      child: SizedBox(
                        width: double.infinity,
                        height: 55,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DetailsScreen(
                                  planet: selectedPlanet,
                                ),
                              ),
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF43838),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                          ),
                          child: const Text(
                            'Explore',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 25),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
