
import 'package:flutter/material.dart';
import '../models/planet.dart';
import '../widgets/planet_info.dart';

class DetailsScreen extends StatelessWidget {
  final Planet planet;

  const DetailsScreen({
    super.key,
    required this.planet,
  });

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D0D),
      body: SafeArea(
        child: Stack(
          children: [
            // Full screen background
            Positioned.fill(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  const ColoredBox(
                    color: Color(0xFF0D0D0D),
                  ),

                  // Background planet
                  Positioned(
                    top: -140,
                    left: 0,
                    right: 0,
                    height: screenHeight * 0.55,
                    child: Image.asset(
                      'assets/images/space.png',
                      fit: BoxFit.cover,
                      alignment: Alignment.center,
                    ),
                  ),

                  // Background gradient
                  Positioned(
                    top: 0,
                    left: 0,
                    right: 0,
                    height: screenHeight * 0.48,
                    child: const DecoratedBox(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Colors.transparent,
                            Color(0x990D0D0D),
                            Color(0xFF0D0D0D),
                          ],
                          stops: [0.2, 0.7, 1.0],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Page content
            SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 30),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: const Icon(
                          Icons.arrow_back,
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          planet.name,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 23,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 25),

                  Center(
                    child: Image.asset(
                      planet.detailsImage,
                      height: screenHeight * 0.30,
                      width: double.infinity,
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(
                          Icons.public,
                          color: Colors.white,
                          size: 150,
                        );
                      },
                    ),
                  ),

                  const SizedBox(height: 25),

                  PlanetInfo(planet: planet),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
