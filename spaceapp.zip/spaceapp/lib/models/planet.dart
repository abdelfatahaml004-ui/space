class Planet {
  final String name;
  final String image;
  final String detailsImage;
  final String description;
  final String distance;
  final String day;
  final String year;
  final String radius;
  final String mass;
  final String gravity;
  final String surfaceArea;

  const Planet({
    required this.name,
    required this.image,
    required this.detailsImage,
    required this.description,
    required this.distance,
    required this.day,
    required this.year,
    required this.radius,
    required this.mass,
    required this.gravity,
    required this.surfaceArea,
  });
}